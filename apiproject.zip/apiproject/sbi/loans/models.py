from django.db import models

# Create your models here.
class PersonLoanModel(models.Model):
    loanid = models.IntegerField(primary_key=True)
    cust_name = models.CharField(max_length=30)
    cust_email = models.EmailField()
    loan_amount = models.FloatField()
    loan_tenure = models.FloatField()
    loan_emi = models.IntegerField()
    roi = models.FloatField()
