from django.contrib import admin
from .models import PersonLoanModel
# Register your models here.

class PersonalLoanAdmin(admin.ModelAdmin):
    list_display = ['loanid','cust_name','cust_email','loan_amount','loan_tenure','loan_emi','roi']


admin.site.register(PersonLoanModel,PersonalLoanAdmin)