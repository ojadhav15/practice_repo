from rest_framework import serializers
from .models import PersonLoanModel

class PersonalSer(serializers.ModelSerializer):
    class Meta:
        model = PersonLoanModel
        fields = '__all__'

